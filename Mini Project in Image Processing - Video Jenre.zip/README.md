# Video-Genre
Mini project in Image Processing, in which we create a tool that classify video to its correct genre- from  different number of jenres.
